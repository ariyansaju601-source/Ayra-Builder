package com.ayra.assistant.services

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.ayra.assistant.R
import com.ayra.assistant.activities.MainActivity

/**
 * Background service that listens for wake word "Hey AYRA"
 * Uses continuous SpeechRecognizer in background
 */
class WakeWordService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(2, buildNotification())
        // TODO: Integrate Porcupine wake word engine or
        // use Google SpeechRecognizer with continuous mode
        startWakeWordDetection()
    }

    private fun startWakeWordDetection() {
        // Basic implementation using keyword in partial results
        // For production: use Picovoice Porcupine for "Hey AYRA"
        // Free tier: https://console.picovoice.ai/
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            "AYRA_WAKE", "AYRA Wake Word", NotificationManager.IMPORTANCE_MIN
        )
        channel.description = "AYRA কে সর্বদা শুনছে"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "AYRA_WAKE")
            .setContentTitle("AYRA শুনছে...")
            .setContentText("\"Hey AYRA\" বলুন")
            .setSmallIcon(R.drawable.ic_ayra)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }
}
