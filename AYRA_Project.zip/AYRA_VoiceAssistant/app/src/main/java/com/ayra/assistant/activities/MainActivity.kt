package com.ayra.assistant.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.ayra.assistant.R
import com.ayra.assistant.models.ChatMessage
import com.ayra.assistant.services.AIService
import com.ayra.assistant.services.AppLaunchService
import com.ayra.assistant.utils.AyraAdapter
import com.ayra.assistant.utils.PrefsHelper
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AyraAdapter
    private lateinit var inputText: EditText
    private lateinit var sendBtn: ImageButton
    private lateinit var micBtn: ImageButton
    private lateinit var lottieOrb: LottieAnimationView
    private lateinit var statusText: TextView
    private lateinit var settingsBtn: ImageButton
    private lateinit var floatingBtn: ImageButton

    private lateinit var tts: TextToSpeech
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var aiService: AIService
    private lateinit var appLauncher: AppLaunchService
    private lateinit var prefs: PrefsHelper

    private val messages = mutableListOf<ChatMessage>()
    private var isMicActive = false
    private var ttsReady = false

    companion object {
        const val PERMISSION_REQUEST = 100
        val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.SEND_SMS
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsHelper(this)
        aiService = AIService(this)
        appLauncher = AppLaunchService(this)

        initViews()
        initTTS()
        initSpeechRecognizer()
        checkPermissions()
        setupListeners()

        // Greet user on start
        Handler(android.os.Looper.getMainLooper()).postDelayed({
            addAyraMessage("হ্যালো! আমি AYRA, আপনার AI সহকারী। আমি কীভাবে সাহায্য করতে পারি?")
        }, 1000)
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recycler_chat)
        inputText = findViewById(R.id.input_text)
        sendBtn = findViewById(R.id.btn_send)
        micBtn = findViewById(R.id.btn_mic)
        lottieOrb = findViewById(R.id.lottie_orb)
        statusText = findViewById(R.id.status_text)
        settingsBtn = findViewById(R.id.btn_settings)
        floatingBtn = findViewById(R.id.btn_floating)

        adapter = AyraAdapter(messages)
        recyclerView.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        recyclerView.adapter = adapter
    }

    private fun initTTS() {
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Try Bengali first, fallback to English
            val bengaliResult = tts.setLanguage(Locale("bn", "BD"))
            if (bengaliResult == TextToSpeech.LANG_MISSING_DATA ||
                bengaliResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.ENGLISH)
            }
            // Set female/girl voice
            val voices = tts.voices
            val femaleVoice = voices?.filter { v ->
                v.name.contains("female", ignoreCase = true) ||
                v.name.contains("f-", ignoreCase = true) ||
                v.features.contains("gender:female")
            }?.firstOrNull()
            femaleVoice?.let { tts.voice = it }

            // Slow down speed slightly for natural feel
            tts.setSpeechRate(0.88f)
            tts.setPitch(1.1f)
            ttsReady = true
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        // Strip markdown for TTS
        val clean = text.replace(Regex("\\*\\*(.*?)\\*\\*"), "$1")
            .replace(Regex("\\*(.*?)\\*"), "$1")
            .replace(Regex("#{1,6} "), "")
            .replace("`", "")
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "AYRA_${System.currentTimeMillis()}")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread { lottieOrb.playAnimation() }
            }
            override fun onDone(utteranceId: String?) {
                runOnUiThread { lottieOrb.pauseAnimation() }
            }
            override fun onError(utteranceId: String?) {
                runOnUiThread { lottieOrb.pauseAnimation() }
            }
        })
    }

    private fun initSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "শুনছি..."
                lottieOrb.playAnimation()
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                statusText.text = "চিন্তা করছি..."
            }
            override fun onError(error: Int) {
                statusText.text = "আবার চেষ্টা করুন"
                isMicActive = false
                micBtn.setImageResource(R.drawable.ic_mic)
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: return
                inputText.setText(text)
                isMicActive = false
                micBtn.setImageResource(R.drawable.ic_mic)
                processUserInput(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun setupListeners() {
        sendBtn.setOnClickListener {
            val text = inputText.text.toString().trim()
            if (text.isNotEmpty()) {
                processUserInput(text)
                inputText.setText("")
            }
        }

        micBtn.setOnClickListener {
            if (!isMicActive) startListening() else stopListening()
        }

        settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        floatingBtn.setOnClickListener {
            startService(Intent(this, com.ayra.assistant.services.FloatingOrbService::class.java))
            Toast.makeText(this, "Floating AYRA চালু!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission needed", Toast.LENGTH_SHORT).show()
            return
        }
        isMicActive = true
        micBtn.setImageResource(R.drawable.ic_mic_active)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.getLanguage())
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, prefs.getLanguage())
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, prefs.getLanguage())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer.startListening(intent)
    }

    private fun stopListening() {
        isMicActive = false
        micBtn.setImageResource(R.drawable.ic_mic)
        speechRecognizer.stopListening()
    }

    private fun processUserInput(input: String) {
        addUserMessage(input)
        statusText.text = "চিন্তা করছি..."

        // Check for app launch commands first (root/accessibility)
        val appLaunchHandled = appLauncher.handleCommand(input)
        if (appLaunchHandled) {
            statusText.text = "প্রস্তুত"
            return
        }

        // Send to AI
        lifecycleScope.launch {
            try {
                val response = aiService.sendMessage(input)
                addAyraMessage(response)
                speak(response)
                statusText.text = "প্রস্তুত"
            } catch (e: Exception) {
                val err = "মাফ করবেন, কোনো সমস্যা হয়েছে: ${e.message}"
                addAyraMessage(err)
                statusText.text = "ত্রুটি"
            }
        }
    }

    private fun addUserMessage(text: String) {
        messages.add(ChatMessage(text, isUser = true))
        adapter.notifyItemInserted(messages.size - 1)
        recyclerView.scrollToPosition(messages.size - 1)
    }

    private fun addAyraMessage(text: String) {
        messages.add(ChatMessage(text, isUser = false))
        adapter.notifyItemInserted(messages.size - 1)
        recyclerView.scrollToPosition(messages.size - 1)
    }

    private fun checkPermissions() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::tts.isInitialized) tts.shutdown()
        if (::speechRecognizer.isInitialized) speechRecognizer.destroy()
    }
}
