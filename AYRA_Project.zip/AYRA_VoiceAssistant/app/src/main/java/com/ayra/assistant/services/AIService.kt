package com.ayra.assistant.services

import android.content.Context
import com.ayra.assistant.utils.PrefsHelper
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

class AIService(context: Context) {

    private val prefs = PrefsHelper(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    // Conversation history for context
    private val conversationHistory = mutableListOf<Map<String, String>>()

    // System prompt - AYRA personality
    private val systemPrompt = """
        You are AYRA (Advanced Yielding Response Assistant), a warm, friendly, and highly capable 
        AI voice assistant. You are a girl AI with a caring personality. 
        You speak in the user's language - if they speak Bengali, reply in Bengali. 
        If English, reply in English. Always be helpful, concise, and conversational.
        Your responses should be natural for text-to-speech - avoid heavy markdown.
        When asked to open apps, call, message, or control the phone, confirm the action.
        You are AYRA, not ChatGPT, Gemini, or Grok. You are powered by them but you are AYRA.
    """.trimIndent()

    suspend fun sendMessage(userMessage: String): String = withContext(Dispatchers.IO) {
        val provider = prefs.getAIProvider()
        return@withContext when (provider) {
            "gemini" -> sendToGemini(userMessage)
            "grok" -> sendToGrok(userMessage)
            else -> sendToChatGPT(userMessage) // default: chatgpt
        }
    }

    // ─── GEMINI ───────────────────────────────────────────────────
    private suspend fun sendToGemini(message: String): String {
        val apiKey = prefs.getGeminiKey()
        if (apiKey.isBlank()) throw Exception("Gemini API key সেট করুন Settings-এ")

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"

        // Build contents with history
        val contents = mutableListOf<JsonObject>()

        // Add history (max 10 turns)
        conversationHistory.takeLast(10).forEach { turn ->
            val part = JsonObject().apply {
                addProperty("role", turn["role"])
                add("parts", gson.toJsonTree(listOf(mapOf("text" to turn["content"]))))
            }
            contents.add(part)
        }

        // Add current message
        contents.add(JsonObject().apply {
            addProperty("role", "user")
            add("parts", gson.toJsonTree(listOf(mapOf("text" to message))))
        })

        val body = JsonObject().apply {
            add("system_instruction", JsonObject().apply {
                add("parts", gson.toJsonTree(listOf(mapOf("text" to systemPrompt))))
            })
            add("contents", gson.toJsonTree(contents))
            add("generationConfig", JsonObject().apply {
                addProperty("temperature", 0.9)
                addProperty("maxOutputTokens", 800)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("No response")
        val json = gson.fromJson(responseBody, JsonObject::class.java)

        val text = json.getAsJsonArray("candidates")
            ?.get(0)?.asJsonObject
            ?.getAsJsonObject("content")
            ?.getAsJsonArray("parts")
            ?.get(0)?.asJsonObject
            ?.get("text")?.asString
            ?: throw Exception("Gemini response parse error")

        // Save to history
        conversationHistory.add(mapOf("role" to "user", "content" to message))
        conversationHistory.add(mapOf("role" to "model", "content" to text))

        return text
    }

    // ─── CHATGPT ──────────────────────────────────────────────────
    private suspend fun sendToChatGPT(message: String): String {
        val apiKey = prefs.getChatGPTKey()
        if (apiKey.isBlank()) throw Exception("ChatGPT API key সেট করুন Settings-এ")

        val messages = mutableListOf<Map<String, String>>()
        messages.add(mapOf("role" to "system", "content" to systemPrompt))

        // Add history
        conversationHistory.takeLast(10).forEach { messages.add(it) }
        messages.add(mapOf("role" to "user", "content" to message))

        val body = JsonObject().apply {
            addProperty("model", "gpt-4o-mini")
            add("messages", gson.toJsonTree(messages))
            addProperty("max_tokens", 800)
            addProperty("temperature", 0.9)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("No response")
        val json = gson.fromJson(responseBody, JsonObject::class.java)

        val text = json.getAsJsonArray("choices")
            ?.get(0)?.asJsonObject
            ?.getAsJsonObject("message")
            ?.get("content")?.asString
            ?: throw Exception("ChatGPT response parse error: $responseBody")

        conversationHistory.add(mapOf("role" to "user", "content" to message))
        conversationHistory.add(mapOf("role" to "assistant", "content" to text))

        return text
    }

    // ─── GROK ─────────────────────────────────────────────────────
    private suspend fun sendToGrok(message: String): String {
        val apiKey = prefs.getGrokKey()
        if (apiKey.isBlank()) throw Exception("Grok API key সেট করুন Settings-এ")

        val messages = mutableListOf<Map<String, String>>()
        messages.add(mapOf("role" to "system", "content" to systemPrompt))
        conversationHistory.takeLast(10).forEach { messages.add(it) }
        messages.add(mapOf("role" to "user", "content" to message))

        val body = JsonObject().apply {
            addProperty("model", "grok-beta")
            add("messages", gson.toJsonTree(messages))
            addProperty("max_tokens", 800)
            addProperty("temperature", 0.9)
        }

        val request = Request.Builder()
            .url("https://api.x.ai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("No response")
        val json = gson.fromJson(responseBody, JsonObject::class.java)

        val text = json.getAsJsonArray("choices")
            ?.get(0)?.asJsonObject
            ?.getAsJsonObject("message")
            ?.get("content")?.asString
            ?: throw Exception("Grok response parse error")

        conversationHistory.add(mapOf("role" to "user", "content" to message))
        conversationHistory.add(mapOf("role" to "assistant", "content" to text))

        return text
    }

    fun clearHistory() {
        conversationHistory.clear()
    }
}
