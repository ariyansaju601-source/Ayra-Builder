# 📦 এখানে ZIP রাখুন

এই `upload/` ফোল্ডারে AYRA_VoiceAssistant.zip রাখুন।

ZIP push হলেই GitHub Actions automatically APK build করবে!

## Steps:
1. এই ফোল্ডারে ZIP drag & drop করুন
2. Commit & Push
3. Actions tab → AYRA-APK → Download
